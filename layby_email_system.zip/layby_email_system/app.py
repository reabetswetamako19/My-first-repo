from flask import Flask, render_template, request, jsonify
from flask_mail import Mail, Message
import os

app = Flask(__name__)

# Mail config
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USERNAME'] = 'your_email@example.com'
app.config['MAIL_PASSWORD'] = 'your_password'
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USE_SSL'] = False

mail = Mail(app)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/send-email', methods=['POST'])
def send_email():
    data = request.form
    customer_name = data.get('customerName')
    email = data.get('email')
    reference_number = data.get('referenceNumber')
    invoice_number = data.get('invoiceNumber')
    first_payment = data.get('firstPayment')

    invoice_path = os.path.join('invoices', f'{invoice_number}.pdf')

    msg = Message(
        subject='Your Layby Invoice from Table Charm Direct',
        sender=app.config['MAIL_USERNAME'],
        recipients=[email]
    )

    msg.body = f"""
Dear {customer_name},

Thank you for choosing the layby option with Table Charm Direct. Please find your layby invoice attached for your reference.

Layby Period: 3 months
First Payment Due: R{first_payment}
Layby Reference Number: {reference_number}
Invoice Number: {invoice_number}

Please make your instalments to:
Bank: FNB
Account Number: 63112857537

Proof of payment: Reabetswet@tablecharm.co.za

Thank you for choosing Table Charm Direct.
"""

    if os.path.exists(invoice_path):
        with app.open_resource(invoice_path) as fp:
            msg.attach(f'{invoice_number}.pdf', 'application/pdf', fp.read())

    try:
        mail.send(msg)
        return jsonify({'message': 'Email sent successfully.'}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)